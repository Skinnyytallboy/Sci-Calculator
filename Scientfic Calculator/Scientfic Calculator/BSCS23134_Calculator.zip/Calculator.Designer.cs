﻿namespace Scientfic_Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculator));
            this.Screen = new System.Windows.Forms.TextBox();
            this.Sign = new System.Windows.Forms.Button();
            this.Zero = new System.Windows.Forms.Button();
            this.Equal = new System.Windows.Forms.Button();
            this.Deci = new System.Windows.Forms.Button();
            this.pow = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.B2O = new System.Windows.Forms.Button();
            this.Mult = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Factorial = new System.Windows.Forms.Button();
            this.Divide = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.B2D = new System.Windows.Forms.Button();
            this.Tane = new System.Windows.Forms.Button();
            this.Cose = new System.Windows.Forms.Button();
            this.Sine = new System.Windows.Forms.Button();
            this.Mod = new System.Windows.Forms.Button();
            this.B2H = new System.Windows.Forms.Button();
            this.Plus = new System.Windows.Forms.Button();
            this.Subtract = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Cut = new System.Windows.Forms.Button();
            this.D2B = new System.Windows.Forms.Button();
            this.D2O = new System.Windows.Forms.Button();
            this.D2H = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Screen
            // 
            this.Screen.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Screen.Location = new System.Drawing.Point(25, 32);
            this.Screen.Margin = new System.Windows.Forms.Padding(2);
            this.Screen.Multiline = true;
            this.Screen.Name = "Screen";
            this.Screen.ReadOnly = true;
            this.Screen.Size = new System.Drawing.Size(313, 80);
            this.Screen.TabIndex = 1;
            this.Screen.Text = "0";
            this.Screen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Sign
            // 
            this.Sign.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sign.Location = new System.Drawing.Point(0, 476);
            this.Sign.Margin = new System.Windows.Forms.Padding(2);
            this.Sign.Name = "Sign";
            this.Sign.Size = new System.Drawing.Size(75, 50);
            this.Sign.TabIndex = 0;
            this.Sign.Text = "±";
            this.Sign.UseVisualStyleBackColor = true;
            this.Sign.Click += new System.EventHandler(this.Sign_Click);
            // 
            // Zero
            // 
            this.Zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero.Location = new System.Drawing.Point(73, 476);
            this.Zero.Margin = new System.Windows.Forms.Padding(2);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(75, 50);
            this.Zero.TabIndex = 2;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = true;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // Equal
            // 
            this.Equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equal.Location = new System.Drawing.Point(219, 428);
            this.Equal.Margin = new System.Windows.Forms.Padding(2);
            this.Equal.Name = "Equal";
            this.Equal.Size = new System.Drawing.Size(75, 100);
            this.Equal.TabIndex = 4;
            this.Equal.Text = "=";
            this.Equal.UseVisualStyleBackColor = true;
            this.Equal.Click += new System.EventHandler(this.Equal_Click);
            // 
            // Deci
            // 
            this.Deci.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deci.Location = new System.Drawing.Point(146, 476);
            this.Deci.Margin = new System.Windows.Forms.Padding(2);
            this.Deci.Name = "Deci";
            this.Deci.Size = new System.Drawing.Size(75, 50);
            this.Deci.TabIndex = 3;
            this.Deci.Text = ".";
            this.Deci.UseVisualStyleBackColor = true;
            this.Deci.Click += new System.EventHandler(this.Deci_Click);
            // 
            // pow
            // 
            this.pow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pow.Location = new System.Drawing.Point(292, 476);
            this.pow.Margin = new System.Windows.Forms.Padding(2);
            this.pow.Name = "pow";
            this.pow.Size = new System.Drawing.Size(75, 50);
            this.pow.TabIndex = 5;
            this.pow.Text = "pow";
            this.pow.UseVisualStyleBackColor = true;
            this.pow.Click += new System.EventHandler(this.pow_Click);
            // 
            // log
            // 
            this.log.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log.Location = new System.Drawing.Point(292, 428);
            this.log.Margin = new System.Windows.Forms.Padding(2);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(75, 50);
            this.log.TabIndex = 10;
            this.log.Text = "log";
            this.log.UseVisualStyleBackColor = true;
            this.log.Click += new System.EventHandler(this.log_Click);
            // 
            // Three
            // 
            this.Three.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three.Location = new System.Drawing.Point(146, 428);
            this.Three.Margin = new System.Windows.Forms.Padding(2);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(75, 50);
            this.Three.TabIndex = 8;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = true;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // Two
            // 
            this.Two.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two.Location = new System.Drawing.Point(73, 428);
            this.Two.Margin = new System.Windows.Forms.Padding(2);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(75, 50);
            this.Two.TabIndex = 7;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = true;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // One
            // 
            this.One.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One.Location = new System.Drawing.Point(0, 428);
            this.One.Margin = new System.Windows.Forms.Padding(2);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(75, 50);
            this.One.TabIndex = 6;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = true;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // B2O
            // 
            this.B2O.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2O.Location = new System.Drawing.Point(292, 332);
            this.B2O.Margin = new System.Windows.Forms.Padding(2);
            this.B2O.Name = "B2O";
            this.B2O.Size = new System.Drawing.Size(75, 50);
            this.B2O.TabIndex = 20;
            this.B2O.Text = "B2O";
            this.B2O.UseVisualStyleBackColor = true;
            this.B2O.Click += new System.EventHandler(this.B2O_Click);
            // 
            // Mult
            // 
            this.Mult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mult.Location = new System.Drawing.Point(219, 332);
            this.Mult.Margin = new System.Windows.Forms.Padding(2);
            this.Mult.Name = "Mult";
            this.Mult.Size = new System.Drawing.Size(75, 50);
            this.Mult.TabIndex = 19;
            this.Mult.Text = "*";
            this.Mult.UseVisualStyleBackColor = true;
            this.Mult.Click += new System.EventHandler(this.Mult_Click);
            // 
            // Nine
            // 
            this.Nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nine.Location = new System.Drawing.Point(146, 332);
            this.Nine.Margin = new System.Windows.Forms.Padding(2);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(75, 50);
            this.Nine.TabIndex = 18;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = true;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // Eight
            // 
            this.Eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight.Location = new System.Drawing.Point(73, 332);
            this.Eight.Margin = new System.Windows.Forms.Padding(2);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(75, 50);
            this.Eight.TabIndex = 17;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = true;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Seven
            // 
            this.Seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven.Location = new System.Drawing.Point(0, 332);
            this.Seven.Margin = new System.Windows.Forms.Padding(2);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(75, 50);
            this.Seven.TabIndex = 16;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = true;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Factorial
            // 
            this.Factorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Factorial.Location = new System.Drawing.Point(292, 380);
            this.Factorial.Margin = new System.Windows.Forms.Padding(2);
            this.Factorial.Name = "Factorial";
            this.Factorial.Size = new System.Drawing.Size(75, 50);
            this.Factorial.TabIndex = 15;
            this.Factorial.Text = "n!";
            this.Factorial.UseVisualStyleBackColor = true;
            this.Factorial.Click += new System.EventHandler(this.Factorial_Click);
            // 
            // Divide
            // 
            this.Divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Divide.Location = new System.Drawing.Point(219, 380);
            this.Divide.Margin = new System.Windows.Forms.Padding(2);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(75, 50);
            this.Divide.TabIndex = 14;
            this.Divide.Text = "/";
            this.Divide.UseVisualStyleBackColor = true;
            this.Divide.Click += new System.EventHandler(this.Divide_Click);
            // 
            // Six
            // 
            this.Six.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six.Location = new System.Drawing.Point(146, 380);
            this.Six.Margin = new System.Windows.Forms.Padding(2);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(75, 50);
            this.Six.TabIndex = 13;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = true;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // Five
            // 
            this.Five.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five.Location = new System.Drawing.Point(73, 380);
            this.Five.Margin = new System.Windows.Forms.Padding(2);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(75, 50);
            this.Five.TabIndex = 12;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = true;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Four
            // 
            this.Four.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four.Location = new System.Drawing.Point(0, 380);
            this.Four.Margin = new System.Windows.Forms.Padding(2);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(75, 50);
            this.Four.TabIndex = 11;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = true;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(292, 188);
            this.button26.Margin = new System.Windows.Forms.Padding(2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 50);
            this.button26.TabIndex = 35;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(146, 188);
            this.button28.Margin = new System.Windows.Forms.Padding(2);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 50);
            this.button28.TabIndex = 33;
            this.button28.Text = "tanh";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(73, 188);
            this.button29.Margin = new System.Windows.Forms.Padding(2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 50);
            this.button29.TabIndex = 32;
            this.button29.Text = "cosh";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(0, 188);
            this.button30.Margin = new System.Windows.Forms.Padding(2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 50);
            this.button30.TabIndex = 31;
            this.button30.Text = "sinh";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // B2D
            // 
            this.B2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2D.Location = new System.Drawing.Point(292, 236);
            this.B2D.Margin = new System.Windows.Forms.Padding(2);
            this.B2D.Name = "B2D";
            this.B2D.Size = new System.Drawing.Size(75, 50);
            this.B2D.TabIndex = 30;
            this.B2D.Text = "B2D";
            this.B2D.UseVisualStyleBackColor = true;
            this.B2D.Click += new System.EventHandler(this.B2D_Click);
            // 
            // Tane
            // 
            this.Tane.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tane.Location = new System.Drawing.Point(219, 236);
            this.Tane.Margin = new System.Windows.Forms.Padding(2);
            this.Tane.Name = "Tane";
            this.Tane.Size = new System.Drawing.Size(75, 50);
            this.Tane.TabIndex = 29;
            this.Tane.Text = "tan";
            this.Tane.UseVisualStyleBackColor = true;
            this.Tane.Click += new System.EventHandler(this.Tane_Click);
            // 
            // Cose
            // 
            this.Cose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cose.Location = new System.Drawing.Point(146, 236);
            this.Cose.Margin = new System.Windows.Forms.Padding(2);
            this.Cose.Name = "Cose";
            this.Cose.Size = new System.Drawing.Size(75, 50);
            this.Cose.TabIndex = 28;
            this.Cose.Text = "cos";
            this.Cose.UseVisualStyleBackColor = true;
            this.Cose.Click += new System.EventHandler(this.Cose_Click);
            // 
            // Sine
            // 
            this.Sine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sine.Location = new System.Drawing.Point(73, 236);
            this.Sine.Margin = new System.Windows.Forms.Padding(2);
            this.Sine.Name = "Sine";
            this.Sine.Size = new System.Drawing.Size(75, 50);
            this.Sine.TabIndex = 27;
            this.Sine.Text = "sin";
            this.Sine.UseVisualStyleBackColor = true;
            this.Sine.Click += new System.EventHandler(this.Sine_Click);
            // 
            // Mod
            // 
            this.Mod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mod.Location = new System.Drawing.Point(0, 236);
            this.Mod.Margin = new System.Windows.Forms.Padding(2);
            this.Mod.Name = "Mod";
            this.Mod.Size = new System.Drawing.Size(75, 50);
            this.Mod.TabIndex = 26;
            this.Mod.Text = "%";
            this.Mod.UseVisualStyleBackColor = true;
            this.Mod.Click += new System.EventHandler(this.Mod_Click);
            // 
            // B2H
            // 
            this.B2H.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2H.Location = new System.Drawing.Point(292, 284);
            this.B2H.Margin = new System.Windows.Forms.Padding(2);
            this.B2H.Name = "B2H";
            this.B2H.Size = new System.Drawing.Size(75, 50);
            this.B2H.TabIndex = 25;
            this.B2H.Text = "B2H";
            this.B2H.UseVisualStyleBackColor = true;
            this.B2H.Click += new System.EventHandler(this.B2H_Click);
            // 
            // Plus
            // 
            this.Plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Plus.Location = new System.Drawing.Point(219, 284);
            this.Plus.Margin = new System.Windows.Forms.Padding(2);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(75, 50);
            this.Plus.TabIndex = 24;
            this.Plus.Text = "+";
            this.Plus.UseVisualStyleBackColor = true;
            this.Plus.Click += new System.EventHandler(this.Plus_Click);
            // 
            // Subtract
            // 
            this.Subtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Subtract.Location = new System.Drawing.Point(146, 284);
            this.Subtract.Margin = new System.Windows.Forms.Padding(2);
            this.Subtract.Name = "Subtract";
            this.Subtract.Size = new System.Drawing.Size(75, 50);
            this.Subtract.TabIndex = 23;
            this.Subtract.Text = "-";
            this.Subtract.UseVisualStyleBackColor = true;
            this.Subtract.Click += new System.EventHandler(this.Subtract_Click);
            // 
            // Clear
            // 
            this.Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.Location = new System.Drawing.Point(73, 284);
            this.Clear.Margin = new System.Windows.Forms.Padding(2);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 50);
            this.Clear.TabIndex = 22;
            this.Clear.Text = "CE";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Cut
            // 
            this.Cut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cut.Location = new System.Drawing.Point(0, 284);
            this.Cut.Margin = new System.Windows.Forms.Padding(2);
            this.Cut.Name = "Cut";
            this.Cut.Size = new System.Drawing.Size(75, 50);
            this.Cut.TabIndex = 21;
            this.Cut.Text = "⌫";
            this.Cut.UseVisualStyleBackColor = true;
            this.Cut.Click += new System.EventHandler(this.Cut_Click);
            // 
            // D2B
            // 
            this.D2B.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2B.Location = new System.Drawing.Point(0, 140);
            this.D2B.Margin = new System.Windows.Forms.Padding(2);
            this.D2B.Name = "D2B";
            this.D2B.Size = new System.Drawing.Size(75, 50);
            this.D2B.TabIndex = 36;
            this.D2B.Text = "D2B";
            this.D2B.UseVisualStyleBackColor = true;
            // 
            // D2O
            // 
            this.D2O.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2O.Location = new System.Drawing.Point(73, 140);
            this.D2O.Margin = new System.Windows.Forms.Padding(2);
            this.D2O.Name = "D2O";
            this.D2O.Size = new System.Drawing.Size(75, 50);
            this.D2O.TabIndex = 37;
            this.D2O.Text = "D2O";
            this.D2O.UseVisualStyleBackColor = true;
            // 
            // D2H
            // 
            this.D2H.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2H.Location = new System.Drawing.Point(146, 140);
            this.D2H.Margin = new System.Windows.Forms.Padding(2);
            this.D2H.Name = "D2H";
            this.D2H.Size = new System.Drawing.Size(75, 50);
            this.D2H.TabIndex = 38;
            this.D2H.Text = "D2H";
            this.D2H.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(219, 188);
            this.button27.Margin = new System.Windows.Forms.Padding(2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 50);
            this.button27.TabIndex = 34;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(292, 140);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 50);
            this.button21.TabIndex = 40;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(219, 140);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 50);
            this.button22.TabIndex = 39;
            this.button22.Text = "button22";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 525);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.D2H);
            this.Controls.Add(this.D2O);
            this.Controls.Add(this.D2B);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.B2D);
            this.Controls.Add(this.Tane);
            this.Controls.Add(this.Cose);
            this.Controls.Add(this.Sine);
            this.Controls.Add(this.Mod);
            this.Controls.Add(this.B2H);
            this.Controls.Add(this.Plus);
            this.Controls.Add(this.Subtract);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Cut);
            this.Controls.Add(this.B2O);
            this.Controls.Add(this.Mult);
            this.Controls.Add(this.Nine);
            this.Controls.Add(this.Eight);
            this.Controls.Add(this.Seven);
            this.Controls.Add(this.Factorial);
            this.Controls.Add(this.Divide);
            this.Controls.Add(this.Six);
            this.Controls.Add(this.Five);
            this.Controls.Add(this.Four);
            this.Controls.Add(this.log);
            this.Controls.Add(this.Three);
            this.Controls.Add(this.Two);
            this.Controls.Add(this.One);
            this.Controls.Add(this.pow);
            this.Controls.Add(this.Equal);
            this.Controls.Add(this.Deci);
            this.Controls.Add(this.Zero);
            this.Controls.Add(this.Screen);
            this.Controls.Add(this.Sign);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Calculator";
            this.Text = "Scientific Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Screen;
        private System.Windows.Forms.Button Sign;
        private System.Windows.Forms.Button Zero;
        private System.Windows.Forms.Button Equal;
        private System.Windows.Forms.Button Deci;
        private System.Windows.Forms.Button pow;
        private System.Windows.Forms.Button log;
        private System.Windows.Forms.Button Three;
        private System.Windows.Forms.Button Two;
        private System.Windows.Forms.Button One;
        private System.Windows.Forms.Button B2O;
        private System.Windows.Forms.Button Mult;
        private System.Windows.Forms.Button Nine;
        private System.Windows.Forms.Button Eight;
        private System.Windows.Forms.Button Seven;
        private System.Windows.Forms.Button Factorial;
        private System.Windows.Forms.Button Divide;
        private System.Windows.Forms.Button Six;
        private System.Windows.Forms.Button Five;
        private System.Windows.Forms.Button Four;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button B2D;
        private System.Windows.Forms.Button Tane;
        private System.Windows.Forms.Button Cose;
        private System.Windows.Forms.Button Sine;
        private System.Windows.Forms.Button Mod;
        private System.Windows.Forms.Button B2H;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button Subtract;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Cut;
        private System.Windows.Forms.Button D2B;
        private System.Windows.Forms.Button D2O;
        private System.Windows.Forms.Button D2H;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
    }
}

